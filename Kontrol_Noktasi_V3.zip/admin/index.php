<?php 
require_once 'settings.php';
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title><?php echo $settings['title'] ?></title>
 </head>
 <body>
 
 </body>
 </html>