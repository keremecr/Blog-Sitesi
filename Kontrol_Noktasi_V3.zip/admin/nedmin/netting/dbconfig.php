<?php 
define('DBHOST','localhost');
define('DBUSER','root');
define('DBPWD','12345678');
define('DBNAME','panel');
 ?>