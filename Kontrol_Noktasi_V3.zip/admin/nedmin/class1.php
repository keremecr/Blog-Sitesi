<?php 

Class Class1 {

	public function __construct() {

		echo "Sınıf 1";
	}
}

 ?>