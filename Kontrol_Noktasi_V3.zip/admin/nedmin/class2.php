 <?php 

Class Class2 {

	public function __construct() {

		echo "Sınıf 2";
	}
}

 ?>